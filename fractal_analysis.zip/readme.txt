This is the readme.txt file for the fractal analysis package for MATLAB.
Below is a short description for each of the 3 finder functions.

All functions accept a black and white binary image as input, bw_test. I have
only tested the functionality for square images, i.e. L times L pixels.

the input "edge" should be 1 or 0. For edge = 1 the particles on the edge of
image are included, for edge = 0 they are excluded.


* * *

[area perim bw_test] = ap_finder(bw_test,edge)

area = an array of the clusters' areas
perim = an array of the clusters' external perimeters


* * *

[D] = D_finder(bw_test,edge)

D = an array of the clusters' Hausdorff dimensions

* * *

[S,cm,Rs,xi] = conn_finder(bw_test,edge)

S = is the average cluster area
cm = is an array of the centre of mass coordinate pair (x,y) for each cluster
Rs = is an array of gyration radii for each cluster
xi = is the correlation length of the clusters in the image